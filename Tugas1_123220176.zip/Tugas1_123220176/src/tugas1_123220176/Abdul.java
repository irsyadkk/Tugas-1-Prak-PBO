/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220176;

/**
 *
 * @author Irsyad
 */
public class Abdul extends manusia implements keahlian{
    Abdul(String nama,String umur)
    {
        super(nama,umur);
    }
    
    @Override
    void jeniskelamin()
    {
        System.out.println("Jenis Kelamin : Laki - laki");
    }
    
    @Override
    public void spesialis()
    {
        System.out.println("Anggota dengan nama "+nama+" memiliki keahlian di bidang bedah");
    }
    
    @Override
    public void tempattugas()
    {
        System.out.println("Anggota dengan nama "+nama+" ditempatkan di Rumah Sakit Veteran");
    }
    @Override
    public void sertifikat()
    {
        System.out.println("Anggota dengan nama "+nama+" memiliki sertifikat DOKTER dan BEDAH");
    }
}
