/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220176;

/**
 *
 * @author Irsyad
 */
public class Tugas1_123220176 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Perekrutan Anggota Kesehatan !");
        perawat anggota[]=new perawat[5];
        for (int i=0;i<5;i++)
        {
            if(i%3==0)
            {
                anggota[i]=new perawat();
            }
            else if (i%2==0)
            {
                anggota[i]=new suster();
            }
            else
            {
                anggota[i]=new dokter();
            }
        }
        for(int i=0;i<5;i++)
        {
            System.out.println("Status anggota "+i+" : ");
            anggota[i].kenaikangaji();
        }
        for(int i=0;i<5;i++)
        {
            System.out.println("Gaji anggota "+i+" saat ini adalah "+ anggota[i].gettotalgaji());
            
        }
        Abdul jundi; 
        jundi = new Abdul("Abdul Jundi","26");
        jundi.data();
        jundi.jeniskelamin();
        jundi.spesialis();
        jundi.sertifikat();
        jundi.tempattugas();
        
    }
    
}
