/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220176;

/**
 *
 * @author Irsyad
 */
public class dokter extends perawat{
    dokter()
    {
        gaji += 6000000;
        tunjangan += 400000;
        setkasihbonus(500000);
    }
    
    @Override
    void kenaikangaji()
    {
        gaji += 4500000;
        System.out.println("Anda menjadi dokter, gaji anda naik sebesar 4500000");
    }
}
