/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220176;

/**
 *
 * @author Irsyad
 */
public interface keahlian {
    public void spesialis();
    public void sertifikat();
    public void tempattugas();   
}
