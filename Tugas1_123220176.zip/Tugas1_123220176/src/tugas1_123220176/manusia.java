/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220176;

/**
 *
 * @author Irsyad
 */
public abstract class manusia {
    String nama;
    String umur;
    
    public manusia (String nama, String umur)
    {
        this.nama=nama;
        this.umur=umur;
    }
    
    abstract void jeniskelamin();
            
    public void data()
    {
        System.out.println("Data :");
        System.out.println("Nama          : "+nama);
        System.out.println("Umur          : "+umur);
    }
}

