/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220176;

/**
 *
 * @author Irsyad
 */
public class perawat {
    double gaji;
    double tunjangan;
    double bonus;
    
    perawat()
    {
        gaji = 2500000;
        tunjangan = 1000000;
        bonus = 250000;
        System.out.println("Selamat anda menjadi perawat magang, dengan gaji "+ gaji +", tunjangan "+tunjangan+" dan bonus "+bonus);
    }
    private double hitunggaji(double gaji, double tunjangan, double bonus)
    {
        return gaji+bonus+tunjangan;
    }
    void kenaikangaji()
    {
        System.out.println("Anda tetap perawat magang, tidak mendapatkan kenaikan gaji");
    }
    void setkasihbonus(double bonus)
    {
        this.bonus = bonus;
    }
    double gettotalgaji()
    {
         return hitunggaji(gaji,tunjangan,bonus);
    }
}
