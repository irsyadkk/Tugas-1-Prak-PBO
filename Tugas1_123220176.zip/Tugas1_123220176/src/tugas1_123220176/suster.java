/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1_123220176;

/**
 *
 * @author Irsyad
 */
class suster extends perawat {
    suster()
    {
    gaji += 500000;
    tunjangan += 300000;
    setkasihbonus (400000);
    }
    
    @Override
    void kenaikangaji()
    {
        gaji += 1500000;
        System.out.println("Anda menjadi suster, gaji anda naik sebesar 1500000");
    }
}
